# Fresh tomatos movie trailers
## To run
Run the entertainment_center.py in python.
### You will need
* media.py
* fresh_tomatoes.py

## Source code for a Movie Trailer website.
* You run the code with python
* A website opens up with 6 moive posters
* Clicking on the poster will open up a trailer.

## fresh_tomatoes.py
The fresh_tomatoes.py module has a function called open_movies_page that takes in one argument, which is a list of movies, and creates an HTML file which will display all of your favorite movies.

## New features
Included a movie reel navbar


